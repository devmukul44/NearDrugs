<div class="footer-content">
	 <div class="container">
		 <div class="ftr-grids">
			 <div class="col-md-3 ftr-grid">
				 <h4>About Us</h4>
				 <ul>
					 <li><a href="whoweare.php">Who We Are</a></li>
					 <li><a href="contactus.php">Contact Us</a></li>
					 <!--<li><a href="#">Our Sites</a></li>-->
					 <li><a href="termsandconditions.php">Team and conditions</a></li>					 
				 </ul>
			 </div>
			 <div class="col-md-3 ftr-grid">
				 <h4>Customer service</h4>
				 <ul>
					 <li><a href="faq.php">FAQ</a></li>
					 <li><a href="delivery.php">Delivery</a></li>
					 <li><a href="cancellation.php">Cancellation</a></li>					 
				 </ul>
			 </div>
			 <div class="col-md-3 ftr-grid">
				 <h4>Your account</h4>
				 <ul>
					 <li><a href="account.html">Your Account</a></li>					 					 
				 </ul>
			 </div>
			 <div class="col-md-3 ftr-grid">
				 <h4>Categories</h4>
				 <ul>
					 <li><a href="#">First Aid</a></li>
					 <li><a href="#">Cosmetics</a></li>
					 <li><a href="#">Skin</a></li>
					 <li><a href="#">Pain</a></li>
					 <li><a href="#">Surgical</a></li>					 
				 </ul>
			 </div>
			 <div class="clearfix"></div>
		 </div>
	 </div>
</div>