<?php
$query = $_GET['query'];
header("location:products.php?query=$query&cat=&lim=16");
?>