<div class="footer">
	 <div class="container">
		 <div class="store">
			 <ul>
				 <li class="active">OUR STORE LOCATOR::</li>
				 <li><a href="javascript:void(0);">Vellore TamilNadu, 632014</a></li>
				 </ul>
		 </div>		 
		 <div class="copywrite">
			 <p>Copyright © 2016 <a href="http://www.neardrugs.com">NearDrugs</a> All Rights Reserved.</div>			 
		 </div>
	 </div>