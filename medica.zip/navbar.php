<div class="mega_nav">
	
		 <div class="menu_sec">
		 <!-- start header menu -->
		 <ul class="megamenu skyblue">
			 <li class="active grid"><a style="margin-left:3%" class="color1" href="index.php">Home</a></li>
			 <li class="grid"><a class="color2" href="#">Medicines</a>
				<div class="megapanel"style=>
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>First Aid</h4>
								<ul>
									<li><a href="products.php?query=&cat=BURN&lim=16">Burn</a></li>
									<li><a href="products.php?query=&cat=Pain Killer&lim=16">Pain Killer</a></li>
									<li><a href="products.php?query=&cat=Acidity&lim=16">Acidity</a></li>
									<li><a href="products.php?query=&cat=Vomiting&lim=16">Vomitting</a></li>
									<li><a href="products.php?query=&cat=Rashes&lim=16">Rashes</a></li>
									<li><a href="products.php?query=&cat=Itching&lim=16">Itching</a></li>
								</ul>
							</div>	
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Skin</h4>
								<ul>
									<li><a href="products.php?query=&cat=Skin+Allergy&lim=16">Allergic</a></li>
									<li><a href="products.php?query=&cat=Antiseptic&lim=16">Antiseptic</a></li>
									<li><a href="products.php?query=&cat=Fungal+Infection&lim=16">Fungal Infection</a></li>
									<li><a href="products.php?query=&cat=Skin+Allergy&lim=16">Acne</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Eye</h4>
								<ul>
									<li><a href="products.php?query=&cat=Eye+Drops&lim=16">Eye Drops</a></li>
								</ul>	
							</div>												
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Pain</h4>
								<ul>
									<li><a href="products.php?query=&cat=Headache&lim=16">HeadAche</a></li>
									<li><a href="products.php?query=&cat=Cold&lim=16">Cold</a></li>
									<li><a href="products.php?query=&cat=Fever&lim=16">Fever</a></li>
									<li><a href="products.php?query=&cat=Stomach+Pain&lim=16">Stomach Pain</a></li>
									<li><a href="products.php?query=&cat=Inflammation&lim=16">Inflammation</a></li>
								</ul>	
							</div>						
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Surgical</h4>
								<ul>
									<li><a href="products.php?query=&cat=Bandage&lim=16">Bandage</a></li>
									<li><a href="products.php?query=&cat=Cotton&lim=16">Cotton</a></li>
									<li><a href="products.php?query=&cat=Syringe&lim=16">Syringe</a></li>
								</ul>	
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>
		<!--<li><a class="color4" href="#">General</a>
				<div class="megapanel" style="width:50%;">
					<div class="row">
						<div class="col-md-6">
							<div class="h_nav">
								<h4>Personal Care</h4>
								<ul>
									<li><a href="products.php">Shampoo</a></li>
									<li><a href="products.php">Herbal Soap</a></li>
									<li><a href="products.php">Facewash</a></li>
									<li><a href="products.php">Sanitizer</a></li>
									<li><a href="products.php?type='personalcare'">More...</a></li>
								</ul>
								</div>
								</div>
								<div class="col-md-6">
								<div class="h_nav">
								<h4>Suppliments</h4>
                                  <ul>
									<li><a href="products.php">Shampoo</a></li>
									<li><a href="products.php">Herbal Soap</a></li>
									<li><a href="products.php">Facewash</a></li>
									<li><a href="products.php">Sanitizer</a></li>
									<li><a href="products.php?type='personalcare'">More...</a></li>
								</ul>	
							</div>							
						</div>
						</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>	-->			
				<li><a class="color5" href="checkup_online.php">Checkup Tool</a>
				<li><a class="color6" href="upload.php">Upload</a>
				<li><a class="color7" href="faq.php">FAQ</a>
			   </ul> 
			   <div  class="search">
				 <form action="search.php" method="GET" >
					<input type="text" name="query" value="" placeholder="Search...">
					<input type="submit" value="">
					</form>
			 </div>
			 <div class="clearfix"></div>
		 </div>
	  </div>
</div>